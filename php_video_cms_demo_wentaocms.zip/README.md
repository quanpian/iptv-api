WentaoCMS Demo (MySQL)
======================

Quick start:
1. Upload this package to your server (e.g. /var/www/wentaocms).
2. Edit config.php to set MySQL credentials or set env vars DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT.
3. Run: php init_db.php   (creates database, tables and admin user)
4. Put files under web root (e.g. /var/www/html) and ensure PHP + MySQL are running.
5. Visit front page: http://your-server/
6. Admin login: http://your-server/admin/login.php  (user: admin, pass: admin123)

Security notes:
- Change admin password immediately after first login.
- This is a demo scaffold. Harden for production before public use.
