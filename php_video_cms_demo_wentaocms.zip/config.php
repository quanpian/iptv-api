<?php
// WentaoCMS config - uses env vars if set
$db_host = getenv('DB_HOST') ?: '127.0.0.1';
$db_port = getenv('DB_PORT') ?: '3306';
$db_name = getenv('DB_NAME') ?: 'wentao_cms';
$db_user = getenv('DB_USER') ?: 'wentao_user';
$db_pass = getenv('DB_PASS') ?: 'wentao_pass';

function db_connect(){
    global $db_host,$db_port,$db_name,$db_user,$db_pass;
    $mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name, (int)$db_port);
    if($mysqli->connect_errno){
        die('DB Connection error: '.$mysqli->connect_error);
    }
    $mysqli->set_charset('utf8mb4');
    return $mysqli;
}
?>