<?php
session_start();
require_once __DIR__.'/../config.php';
if(empty($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
$mysqli = db_connect();
$videos = $mysqli->query('SELECT * FROM videos ORDER BY id DESC')->fetch_all(MYSQLI_ASSOC);
?><!doctype html><html><head><meta charset="utf-8"><title>Dashboard - WentaoCMS</title></head><body>
<h2>Dashboard</h2>
<p>Welcome, <?php echo htmlspecialchars($_SESSION['admin_user']);?> | <a href="logout.php">Logout</a></p>
<h3>Videos</h3>
<p><a href="video_edit.php">Add new</a></p>
<table border="1"><tr><th>ID</th><th>Title</th><th>Actions</th></tr>
<?php foreach($videos as $v): ?>
<tr><td><?php echo $v['id'];?></td><td><?php echo htmlspecialchars($v['title']);?></td><td><a href="video_edit.php?id=<?php echo $v['id'];?>">Edit</a></td></tr>
<?php endforeach;?></table>
</body></html>