<?php
session_start();
require_once __DIR__.'/../config.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    $mysqli = db_connect();
    $stmt = $mysqli->prepare('SELECT id,password,role FROM users WHERE username=? LIMIT 1');
    $stmt->bind_param('s',$u); $stmt->execute(); $stmt->store_result(); $stmt->bind_result($id,$hash,$role);
    if($stmt->num_rows && $stmt->fetch() && password_verify($p,$hash)){
        $_SESSION['admin_id'] = $id; $_SESSION['admin_user']=$u; header('Location: dashboard.php'); exit;
    } else {
        $err = 'Invalid credentials';
    }
}
?><!doctype html><html><head><meta charset="utf-8"><title>Admin Login - WentaoCMS</title></head><body>
<h2>Admin Login</h2>
<?php if(!empty($err)) echo '<p style="color:red">'.htmlspecialchars($err).'</p>';?>
<form method="post">
<label>Username: <input name="username" required></label><br>
<label>Password: <input type="password" name="password" required></label><br>
<button>Login</button>
</form>
</body></html>