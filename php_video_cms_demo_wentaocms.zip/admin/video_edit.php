<?php
session_start();
require_once __DIR__.'/../config.php';
if(empty($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
$mysqli = db_connect();
$id = intval($_GET['id'] ?? 0);
if($_SERVER['REQUEST_METHOD']==='POST'){
    $title = $_POST['title'] ?? '';
    $desc = $_POST['description'] ?? '';
    $url = $_POST['video_url'] ?? '';
    $thumb = $_POST['thumbnail'] ?? '/assets/img/sample.jpg';
    $cat = intval($_POST['category_id'] ?? 0);
    if($id){
        $stmt = $mysqli->prepare('UPDATE videos SET title=?,description=?,video_url=?,thumbnail=?,category_id=? WHERE id=?');
        $stmt->bind_param('ssssii',$title,$desc,$url,$thumb,$cat,$id); $stmt->execute();
    } else {
        $stmt = $mysqli->prepare('INSERT INTO videos (category_id,title,description,thumbnail,video_url) VALUES (?,?,?,?,?)');
        $stmt->bind_param('issss',$cat,$title,$desc,$thumb,$url); $stmt->execute();
    }
    header('Location: dashboard.php'); exit;
}
$video = ['title'=>'','description'=>'','video_url'=>'','thumbnail'=>'/assets/img/sample.jpg','category_id'=>0];
if($id){ $stmt=$mysqli->prepare('SELECT * FROM videos WHERE id=?'); $stmt->bind_param('i',$id); $stmt->execute(); $res=$stmt->get_result(); if($r=$res->fetch_assoc()) $video=$r; }
$cats = $mysqli->query('SELECT * FROM categories')->fetch_all(MYSQLI_ASSOC);
?><!doctype html><html><head><meta charset="utf-8"><title>Edit Video</title></head><body>
<h2><?php echo $id?'Edit':'Add';?> Video</h2>
<form method="post">
<label>Title: <input name="title" value="<?php echo htmlspecialchars($video['title']);?>"></label><br>
<label>Category: <select name="category_id"><?php foreach($cats as $c) echo '<option value="'.intval($c['id']).'"'.($video['category_id']==$c['id']?' selected':'').'>'.htmlspecialchars($c['name']).'</option>';?></select></label><br>
<label>Thumbnail URL: <input name="thumbnail" value="<?php echo htmlspecialchars($video['thumbnail']);?>"></label><br>
<label>Video URL: <input name="video_url" value="<?php echo htmlspecialchars($video['video_url']);?>"></label><br>
<label>Description:<br><textarea name="description" rows="6" cols="60"><?php echo htmlspecialchars($video['description']);?></textarea></label><br>
<button>Save</button>
</form>
</body></html>