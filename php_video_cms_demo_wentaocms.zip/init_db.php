<?php
require_once 'config.php';
$mysqli = new mysqli($db_host, $db_user, $db_pass, '', (int)$db_port);
if($mysqli->connect_errno){ die('Connect error: '.$mysqli->connect_error); }
// create database if not exists
$mysqli->query("CREATE DATABASE IF NOT EXISTS `{$db_name}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$mysqli->select_db($db_name);

// create tables: users, categories, videos, ads
$queries = [];

$queries[] = "CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

$queries[] = "CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  slug VARCHAR(150) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

$queries[] = "CREATE TABLE IF NOT EXISTS videos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  thumbnail VARCHAR(255),
  video_url VARCHAR(1024),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

$queries[] = "CREATE TABLE IF NOT EXISTS ads (
  id INT AUTO_INCREMENT PRIMARY KEY,
  position VARCHAR(50) NOT NULL,
  title VARCHAR(255),
  image VARCHAR(255),
  target_url VARCHAR(1024),
  is_active TINYINT(1) DEFAULT 1,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

foreach($queries as $q){
    if(!$mysqli->query($q)){
        echo 'Error creating table: '.$mysqli->error."\n";
    }
}

// insert admin user if not exists (password: admin123)
$admin = 'admin';
$pwd = password_hash('admin123', PASSWORD_DEFAULT);
$stmt = $mysqli->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
$stmt->bind_param('s',$admin); $stmt->execute(); $stmt->store_result();
if($stmt->num_rows===0){
    $ins = $mysqli->prepare('INSERT INTO users (username,password,role) VALUES (?,?,?)');
    $role='admin'; $ins->bind_param('sss',$admin,$pwd,$role); $ins->execute();
    echo "Admin user created: admin / admin123\n";
} else {
    echo "Admin user already exists\n";
}
$stmt->close();

// sample categories and videos
$mysqli->query("INSERT IGNORE INTO categories (id,name,slug) VALUES (1,'Movies','movies'),(2,'TV Shows','tv')");
$mysqli->query("INSERT IGNORE INTO videos (id,category_id,title,description,thumbnail,video_url) VALUES
(1,1,'Sample Movie','This is a sample movie for WentaoCMS','/assets/img/sample.jpg','https://example.com/video1.mp4'),
(2,2,'Sample Episode','Sample TV episode','/assets/img/sample.jpg','https://example.com/video2.mp4')");

echo "Database initialized.\n";
?>