<?php
require_once 'config.php';
$mysqli = db_connect();
$cats = $mysqli->query('SELECT * FROM categories ORDER BY id')->fetch_all(MYSQLI_ASSOC);
$videos = $mysqli->query('SELECT v.*, c.name as category_name FROM videos v LEFT JOIN categories c ON v.category_id=c.id ORDER BY v.id DESC LIMIT 20')->fetch_all(MYSQLI_ASSOC);
?><!doctype html>
<html><head><meta charset="utf-8"><title>WentaoCMS Demo</title>
<link rel="stylesheet" href="/assets/css/style.css">
</head><body>
<header><h1>WentaoCMS</h1><nav><?php foreach($cats as $c) echo '<a href="?cat='.urlencode($c['id']).'">'.htmlspecialchars($c['name']).'</a> ';?></nav></header>
<main>
<?php foreach($videos as $v): ?>
<article class="video">
  <h2><?php echo htmlspecialchars($v['title']);?></h2>
  <div class="meta">Category: <?php echo htmlspecialchars($v['category_name']);?></div>
  <img src="<?php echo htmlspecialchars($v['thumbnail']);?>" style="max-width:200px">
  <p><?php echo nl2br(htmlspecialchars($v['description']));?></p>
  <p><a href="<?php echo htmlspecialchars($v['video_url']);?>" target="_blank">Play</a></p>
</article>
<?php endforeach; ?>
</main>
<footer>© WentaoCMS Demo</footer>
</body></html>